Liberty Bancard Master Campaign Pack

Includes:
- Retail campaigns
- Auto campaigns
- Medical / Med Spa campaigns
- Restaurant / QSR campaigns

Each folder contains:
- SDR Outbound
- Inbound Marketing Drips
- Operational / Account Management Emails

All CTAs use {{custom_values.booking_link}} for auto-routing calendars.
